import nodemailer from 'nodemailer';
import twilio from 'twilio';
import cron from 'node-cron';
import db from '../db.ts';

// Configurable intervals in hours
const REMINDER_INTERVALS = {
  LONG: 24,
  SHORT: 2,
};

// Lazy initialization for Twilio
let twilioClient: any = null;
function getTwilioClient() {
  if (!twilioClient && process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
    twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  }
  return twilioClient;
}

// Lazy initialization for Nodemailer
let mailTransporter: any = null;
function getMailTransporter() {
  if (!mailTransporter && process.env.SMTP_HOST) {
    mailTransporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_PORT === '465',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  return mailTransporter;
}

async function sendEmail(to: string, subject: string, text: string) {
  const transporter = getMailTransporter();
  if (!transporter) {
    console.warn('SMTP not configured, skipping email reminder.');
    return;
  }
  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || '"BookMyCare" <no-reply@bookmycare.com>',
      to,
      subject,
      text,
    });
    console.log(`Email sent to ${to}`);
  } catch (error) {
    console.error(`Failed to send email to ${to}:`, error);
  }
}

async function sendSMS(to: string, message: string) {
  const client = getTwilioClient();
  if (!client || !process.env.TWILIO_PHONE_NUMBER) {
    console.warn('Twilio not configured, skipping SMS reminder.');
    return;
  }
  try {
    await client.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to,
    });
    console.log(`SMS sent to ${to}`);
  } catch (error) {
    console.error(`Failed to send SMS to ${to}:`, error);
  }
}

export function initReminderSystem() {
  console.log('Initializing automated reminder system...');

  // Run every 15 minutes
  cron.schedule('*/15 * * * *', async () => {
    console.log('Checking for upcoming appointments to send reminders...');
    const now = new Date();
    
    // Get upcoming approved appointments
    const appointments = db.prepare(`
      SELECT a.*, u_p.name as patient_name, u_p.email as patient_email, u_p.phone as patient_phone,
             u_d.name as doctor_name
      FROM appointments a
      JOIN users u_p ON a.patient_id = u_p.id
      JOIN doctors d ON a.doctor_id = d.id
      JOIN users u_d ON d.user_id = u_d.id
      WHERE a.status = 'approved'
    `).all() as any[];

    for (const app of appointments) {
      // Parse '09:00 AM' or '02:00 PM'
      const [timeStr, modifier] = app.time.split(' ');
      let [hours, minutes] = timeStr.split(':').map(Number);
      if (modifier === 'PM' && hours < 12) hours += 12;
      if (modifier === 'AM' && hours === 12) hours = 0;
      
      const appDateTime = new Date(app.date);
      appDateTime.setHours(hours, minutes, 0, 0);
      
      const diffMs = appDateTime.getTime() - now.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);

      // Long-term reminder (e.g., 24-hour)
      if (diffHours > 0 && diffHours <= REMINDER_INTERVALS.LONG && !app.reminder_24h_sent) {
        const message = `Reminder: You have an appointment with Dr. ${app.doctor_name} on ${app.date} at ${app.time}.`;
        
        if (app.patient_email) {
          await sendEmail(app.patient_email, `Appointment Reminder (${REMINDER_INTERVALS.LONG}h)`, message);
        }
        if (app.patient_phone) {
          await sendSMS(app.patient_phone, message);
        }
        
        db.prepare('UPDATE appointments SET reminder_24h_sent = 1 WHERE id = ?').run(app.id);
      }

      // Short-term reminder (e.g., 2-hour)
      if (diffHours > 0 && diffHours <= REMINDER_INTERVALS.SHORT && !app.reminder_2h_sent) {
        const message = `Urgent Reminder: Your appointment with Dr. ${app.doctor_name} is in ${REMINDER_INTERVALS.SHORT} hours (${app.time}).`;
        
        if (app.patient_email) {
          await sendEmail(app.patient_email, `Appointment Reminder (${REMINDER_INTERVALS.SHORT}h)`, message);
        }
        if (app.patient_phone) {
          await sendSMS(app.patient_phone, message);
        }
        
        db.prepare('UPDATE appointments SET reminder_2h_sent = 1 WHERE id = ?').run(app.id);
      }
    }
  });
}
