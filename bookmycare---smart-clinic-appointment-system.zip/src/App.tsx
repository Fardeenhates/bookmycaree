import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  User, 
  ShieldCheck, 
  LogOut, 
  Menu, 
  X, 
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  CreditCard,
  Plus,
  Users,
  Mail,
  Stethoscope,
  TrendingUp,
  Search,
  Filter,
  ChevronRight,
  MapPin,
  Phone,
  Facebook,
  Twitter,
  Instagram
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User as UserType, Doctor, Appointment, AdminStats } from './types';

// --- COMPONENTS ---

const Navbar = ({ user, onLogout, onNavigate }: { user: UserType | null, onLogout: () => void, onNavigate: (page: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 glass px-6 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
          <div className="bg-sky-600 p-2 rounded-lg">
            <Activity className="text-white w-6 h-6" />
          </div>
          <span className="text-2xl font-bold font-display gradient-text">BookMyCare</span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => onNavigate('home')} className="hover:text-sky-600 transition-colors">Home</button>
          <button onClick={() => onNavigate('about')} className="hover:text-sky-600 transition-colors">About</button>
          <button onClick={() => onNavigate('contact')} className="hover:text-sky-600 transition-colors">Contact</button>
          {user ? (
            <div className="flex items-center gap-4">
              <button 
                onClick={() => onNavigate('dashboard')}
                className="bg-sky-600 text-white px-5 py-2 rounded-full hover:bg-sky-700 transition-all flex items-center gap-2"
              >
                <User className="w-4 h-4" />
                Dashboard
              </button>
              <button onClick={onLogout} className="text-slate-500 hover:text-red-600 transition-colors">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => onNavigate('login')}
              className="bg-sky-600 text-white px-6 py-2 rounded-full hover:bg-sky-700 transition-all"
            >
              Sign In
            </button>
          )}
        </div>

        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-full left-0 w-full bg-white border-t p-6 flex flex-col gap-4 shadow-xl"
          >
            <button onClick={() => { onNavigate('home'); setIsOpen(false); }}>Home</button>
            <button onClick={() => { onNavigate('about'); setIsOpen(false); }}>About</button>
            <button onClick={() => { onNavigate('contact'); setIsOpen(false); }}>Contact</button>
            {user ? (
              <>
                <button onClick={() => { onNavigate('dashboard'); setIsOpen(false); }}>Dashboard</button>
                <button onClick={onLogout} className="text-red-600 text-left">Logout</button>
              </>
            ) : (
              <button onClick={() => { onNavigate('login'); setIsOpen(false); }} className="bg-sky-600 text-white py-2 rounded-full">Sign In</button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = ({ onBook }: { onBook: () => void }) => (
  <section className="pt-32 pb-20 px-6 overflow-hidden">
    <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="inline-flex items-center gap-2 bg-sky-100 text-sky-700 px-4 py-2 rounded-full text-sm font-semibold mb-6">
          <ShieldCheck className="w-4 h-4" />
          Trusted by 10,000+ Patients
        </div>
        <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight mb-6">
          Your Health, <br />
          <span className="gradient-text">Simplified.</span>
        </h1>
        <p className="text-lg text-slate-600 mb-8 max-w-lg">
          Book appointments with top-rated doctors in seconds. Experience a smarter way to manage your healthcare journey.
        </p>
        <div className="flex flex-wrap gap-4">
          <button 
            onClick={onBook}
            className="bg-sky-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-sky-700 hover:shadow-lg transition-all flex items-center gap-2 group"
          >
            Book Appointment Now
            <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
          <button className="px-8 py-4 rounded-full text-lg font-semibold border border-slate-200 hover:bg-slate-50 transition-all">
            Learn More
          </button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="relative"
      >
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-sky-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-emerald-400/20 rounded-full blur-3xl animate-pulse delay-700"></div>
        <img 
          src="https://picsum.photos/seed/medical/800/600" 
          alt="Healthcare" 
          className="rounded-3xl shadow-2xl relative z-10"
          referrerPolicy="no-referrer"
        />
        <div className="absolute -bottom-6 -left-6 glass p-6 rounded-2xl z-20 shadow-xl max-w-[200px]">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-emerald-100 p-2 rounded-lg">
              <CheckCircle className="text-emerald-600 w-5 h-5" />
            </div>
            <span className="font-bold">Verified Doctors</span>
          </div>
          <p className="text-xs text-slate-500">All our specialists are certified and highly experienced.</p>
        </div>
      </motion.div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-slate-900 text-white pt-20 pb-10 px-6">
    <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 mb-16">
      <div className="col-span-2 md:col-span-1">
        <div className="flex items-center gap-2 mb-6">
          <div className="bg-sky-600 p-2 rounded-lg">
            <Activity className="text-white w-6 h-6" />
          </div>
          <span className="text-2xl font-bold font-display">BookMyCare</span>
        </div>
        <p className="text-slate-400 mb-6">
          Making healthcare accessible, reliable, and efficient for everyone.
        </p>
        <div className="flex gap-4">
          <Facebook className="w-5 h-5 text-slate-400 hover:text-sky-400 cursor-pointer" />
          <Twitter className="w-5 h-5 text-slate-400 hover:text-sky-400 cursor-pointer" />
          <Instagram className="w-5 h-5 text-slate-400 hover:text-sky-400 cursor-pointer" />
        </div>
      </div>
      
      <div>
        <h4 className="font-bold mb-6">Quick Links</h4>
        <ul className="space-y-4 text-slate-400">
          <li className="hover:text-white cursor-pointer">Home</li>
          <li className="hover:text-white cursor-pointer">About Us</li>
          <li className="hover:text-white cursor-pointer">Doctors</li>
          <li className="hover:text-white cursor-pointer">Contact</li>
        </ul>
      </div>

      <div>
        <h4 className="font-bold mb-6">Services</h4>
        <ul className="space-y-4 text-slate-400">
          <li className="hover:text-white cursor-pointer">Online Booking</li>
          <li className="hover:text-white cursor-pointer">Consultation</li>
          <li className="hover:text-white cursor-pointer">Emergency Care</li>
          <li className="hover:text-white cursor-pointer">Health Reports</li>
        </ul>
      </div>

      <div>
        <h4 className="font-bold mb-6">Contact Us</h4>
        <ul className="space-y-4 text-slate-400">
          <li className="flex items-center gap-3">
            <MapPin className="w-4 h-4 text-sky-400" />
            123 Health Ave, Medical City
          </li>
          <li className="flex items-center gap-3">
            <Phone className="w-4 h-4 text-sky-400" />
            +1 (234) 567-890
          </li>
          <li className="flex items-center gap-3">
            <Mail className="w-4 h-4 text-sky-400" />
            support@bookmycare.com
          </li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
      © 2026 BookMyCare. All rights reserved.
    </div>
  </footer>
);

// --- MAIN APP COMPONENT ---

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState<UserType | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Auth States
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    role: 'patient',
    phone: '',
    specialization: '',
    degree: '',
    qualification: '',
    experience: '',
    age: '',
    gender: 'male'
  });

  // Data States
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [filter, setFilter] = useState('');

  // Payment State
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [paymentLoading, setPaymentLoading] = useState(false);

  // Doctor Management State
  const [showDoctorModal, setShowDoctorModal] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [googleConnected, setGoogleConnected] = useState(false);
  const [doctorFormData, setDoctorFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    specialization: '',
    degree: '',
    qualification: '',
    experience: '',
    consultation_fee: 500,
    bio: ''
  });

  useEffect(() => {
    if (currentPage === 'home' || currentPage === 'dashboard') {
      fetchDoctors();
    }
    if (user && currentPage === 'dashboard') {
      fetchAppointments();
      fetchGoogleStatus();
      if (user.role === 'admin') fetchStats();
    }
  }, [currentPage, user]);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'GOOGLE_AUTH_SUCCESS') {
        fetchGoogleStatus();
        setMessage({ type: 'success', text: 'Google account connected successfully!' });
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const fetchGoogleStatus = async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/auth/google/status/${user.id}`);
      const data = await res.json();
      setGoogleConnected(data.connected);
    } catch (err) {
      console.error('Failed to fetch Google status');
    }
  };

  const handleGoogleConnect = async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/auth/google/url?userId=${user.id}`);
      const { url } = await res.json();
      window.open(url, 'google_auth', 'width=600,height=700');
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to initiate Google connection' });
    }
  };

  const fetchDoctors = async () => {
    const res = await fetch('/api/doctors');
    const data = await res.json();
    setDoctors(data);
  };

  const fetchAppointments = async () => {
    if (!user) return;
    const res = await fetch(`/api/appointments/${user.id}?role=${user.role}`);
    const data = await res.json();
    setAppointments(data);
  };

  const fetchStats = async () => {
    const res = await fetch('/api/admin/stats');
    const data = await res.json();
    setStats(data);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    if (authMode === 'register' && formData.password !== formData.confirmPassword) {
      setMessage({ type: 'error', text: 'Passwords do not match.' });
      setLoading(false);
      return;
    }

    const endpoint = authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();

      if (data.success) {
        if (authMode === 'login') {
          setUser(data.user);
          setCurrentPage('dashboard');
        } else {
          setAuthMode('login');
          setMessage({ type: 'success', text: 'Registration successful! Please login.' });
        }
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Something went wrong.' });
    } finally {
      setLoading(false);
    }
  };

  const handleBook = async (doctorId: number, date: string, time: string) => {
    if (!user) {
      setCurrentPage('login');
      return;
    }

    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patient_id: user.id, doctor_id: doctorId, date, time })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Appointment booked successfully!' });
        fetchAppointments();
        // Auto-open payment for the new appointment
        const newAppRes = await fetch(`/api/appointments/${user.id}?role=${user.role}`);
        const newAppData = await newAppRes.json();
        const latest = newAppData[0];
        if (latest) {
          setSelectedAppointment(latest);
          setShowPaymentModal(true);
        }
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Booking failed.' });
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAppointment) return;

    setPaymentLoading(true);
    try {
      const res = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          appointment_id: selectedAppointment.id, 
          amount: selectedAppointment.consultation_fee || 500 
        })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: `Payment successful! Transaction ID: ${data.transaction_id}` });
        setShowPaymentModal(false);
        fetchAppointments();
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Payment failed.' });
    } finally {
      setPaymentLoading(false);
    }
  };

  const updateAppointmentStatus = async (id: number, status: string) => {
    const res = await fetch(`/api/appointments/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) fetchAppointments();
  };

  const handleAddDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...doctorFormData, role: 'doctor' }),
      });
      const data = await response.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Doctor added successfully!' });
        setShowDoctorModal(false);
        fetchDoctors();
        fetchStats();
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to add doctor' });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDoctor) return;
    setLoading(true);
    try {
      const response = await fetch(`/api/doctors/${editingDoctor.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(doctorFormData),
      });
      const data = await response.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Doctor updated successfully!' });
        setShowDoctorModal(false);
        fetchDoctors();
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update doctor' });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteDoctor = async (id: number) => {
    if (!confirm('Are you sure you want to delete this doctor? This will also delete their user account.')) return;
    try {
      const response = await fetch(`/api/doctors/${id}`, {
        method: 'DELETE',
      });
      const data = await response.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Doctor deleted successfully!' });
        fetchDoctors();
        fetchStats();
      } else {
        setMessage({ type: 'error', text: data.message });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to delete doctor' });
    }
  };

  const openAddDoctorModal = () => {
    setEditingDoctor(null);
    setDoctorFormData({
      name: '',
      email: '',
      password: '',
      phone: '',
      specialization: '',
      degree: '',
      qualification: '',
      experience: '',
      consultation_fee: 500,
      bio: ''
    });
    setShowDoctorModal(true);
  };

  const openEditDoctorModal = (doc: Doctor) => {
    setEditingDoctor(doc);
    setDoctorFormData({
      name: doc.name,
      email: doc.email,
      password: '',
      phone: doc.phone,
      specialization: doc.specialization,
      degree: doc.degree,
      qualification: doc.qualification,
      experience: doc.experience.toString(),
      consultation_fee: doc.consultation_fee,
      bio: doc.bio || ''
    });
    setShowDoctorModal(true);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('home');
  };

  const toggleAuthMode = () => {
    setAuthMode(authMode === 'login' ? 'register' : 'login');
    setMessage(null);
    setFormData({
      email: '',
      password: '',
      confirmPassword: '',
      name: '',
      role: 'patient',
      phone: '',
      specialization: '',
      degree: '',
      qualification: '',
      experience: '',
      age: '',
      gender: 'male'
    });
  };

  return (
    <div className="min-h-screen">
      <Navbar user={user} onLogout={handleLogout} onNavigate={setCurrentPage} />
      
      {message && (
        <div className={`fixed top-24 right-6 z-[60] p-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce ${message.type === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
          {message.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          {message.text}
          <button onClick={() => setMessage(null)} className="ml-4 opacity-50 hover:opacity-100"><X className="w-4 h-4" /></button>
        </div>
      )}

      <main>
        {currentPage === 'home' && (
          <>
            <Hero onBook={() => setCurrentPage('dashboard')} />
            
            {/* Featured Doctors */}
            <section className="py-20 px-6 bg-slate-100">
              <div className="max-w-7xl mx-auto">
                <div className="text-center mb-16">
                  <h2 className="text-4xl font-display font-bold mb-4">Our Specialists</h2>
                  <p className="text-slate-600 mb-8">Choose from our network of world-class medical professionals.</p>
                  
                  <div className="max-w-md mx-auto relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <input 
                      type="text" 
                      placeholder="Search by specialization (e.g. Cardiologist)..."
                      className="w-full pl-12 pr-4 py-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all shadow-sm"
                      value={filter}
                      onChange={e => setFilter(e.target.value)}
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                  {doctors
                    .filter(d => d.specialization.toLowerCase().includes(filter.toLowerCase()))
                    .slice(0, 6).map((doc, i) => (
                    <motion.div 
                      key={doc.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="glass p-6 rounded-3xl hover:shadow-2xl transition-all"
                    >
                      <img src={`https://picsum.photos/seed/doc${doc.id}/400/300`} className="rounded-2xl mb-6 w-full h-48 object-cover" referrerPolicy="no-referrer" />
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-bold">Dr. {doc.name}</h3>
                          <p className="text-sky-600 font-medium text-sm">{doc.specialization}</p>
                          <p className="text-slate-400 text-xs mt-1">{doc.degree} • {doc.experience} Years Exp.</p>
                        </div>
                        <div className="bg-sky-50 text-sky-700 px-3 py-1 rounded-full text-sm font-bold">
                          ₹{doc.consultation_fee}
                        </div>
                      </div>
                      <div className="mb-4">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Qualification</span>
                        <p className="text-xs font-medium text-slate-700">{doc.qualification || 'Medical Specialist'}</p>
                      </div>
                      <p className="text-slate-500 text-sm mb-6 line-clamp-2">{doc.bio || 'Experienced specialist dedicated to providing the best patient care.'}</p>
                      <button 
                        onClick={() => setCurrentPage('dashboard')}
                        className="w-full py-3 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-all"
                      >
                        View Profile
                      </button>
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>

            {/* Why Choose Us */}
            <section className="py-20 px-6">
              <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
                <div>
                  <h2 className="text-4xl font-display font-bold mb-8">Why Choose BookMyCare?</h2>
                  <div className="space-y-6">
                    {[
                      { icon: Clock, title: '24/7 Availability', desc: 'Book your appointments anytime, anywhere at your convenience.' },
                      { icon: ShieldCheck, title: 'Secure & Private', desc: 'Your medical data is encrypted and handled with utmost privacy.' },
                      { icon: Stethoscope, title: 'Expert Doctors', desc: 'Access to a wide range of verified medical specialists.' },
                    ].map((item, i) => (
                      <div key={i} className="flex gap-4">
                        <div className="bg-sky-100 p-3 rounded-2xl h-fit">
                          <item.icon className="text-sky-600 w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="font-bold text-lg mb-1">{item.title}</h4>
                          <p className="text-slate-500">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <img src="https://picsum.photos/seed/h1/400/500" className="rounded-3xl shadow-lg mt-12" referrerPolicy="no-referrer" />
                  <img src="https://picsum.photos/seed/h2/400/500" className="rounded-3xl shadow-lg" referrerPolicy="no-referrer" />
                </div>
              </div>
            </section>
          </>
        )}

        {currentPage === 'login' && (
          <section className="pt-40 pb-20 px-6 flex justify-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass p-10 rounded-3xl w-full max-w-md shadow-2xl"
            >
              <div className="text-center mb-8">
                <h2 className="text-3xl font-display font-bold mb-2">
                  {authMode === 'login' ? 'Welcome Back' : 'Create Account'}
                </h2>
                <p className="text-slate-500">
                  {authMode === 'login' ? 'Enter your details to access your dashboard' : 'Join our healthcare community today'}
                </p>
              </div>

              <form onSubmit={handleAuth} className="space-y-4">
                {authMode === 'register' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold ml-1">Full Name</label>
                      <input 
                        required
                        type="text" 
                        placeholder="John Doe"
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold ml-1">I am a...</label>
                      <select 
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                        value={formData.role}
                        onChange={e => setFormData({...formData, role: e.target.value})}
                      >
                        <option value="patient">Patient</option>
                        <option value="doctor">Doctor</option>
                      </select>
                    </div>
                    {formData.role === 'patient' && (
                      <div className="space-y-1">
                        <label className="text-sm font-semibold ml-1">Age</label>
                        <input 
                          required
                          type="number" 
                          placeholder="Enter your age"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                          value={formData.age}
                          onChange={e => setFormData({...formData, age: e.target.value})}
                        />
                      </div>
                    )}
                    {formData.role === 'doctor' && (
                      <>
                        <div className="space-y-1">
                          <label className="text-sm font-semibold ml-1">Specialization</label>
                          <input 
                            required
                            type="text" 
                            placeholder="e.g. Cardiologist"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                            value={formData.specialization}
                            onChange={e => setFormData({...formData, specialization: e.target.value})}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-sm font-semibold ml-1">Degree</label>
                            <input 
                              required
                              type="text" 
                              placeholder="e.g. MBBS, MD"
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                              value={formData.degree}
                              onChange={e => setFormData({...formData, degree: e.target.value})}
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-sm font-semibold ml-1">Experience (Years)</label>
                            <input 
                              required
                              type="number" 
                              placeholder="e.g. 10"
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                              value={formData.experience}
                              onChange={e => setFormData({...formData, experience: e.target.value})}
                            />
                          </div>
                        </div>
                        <div className="space-y-1">
                          <label className="text-sm font-semibold ml-1">Qualification</label>
                          <input 
                            required
                            type="text" 
                            placeholder="e.g. Senior Consultant"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                            value={formData.qualification}
                            onChange={e => setFormData({...formData, qualification: e.target.value})}
                          />
                        </div>
                      </>
                    )}
                  </>
                )}
                <div className="space-y-1">
                  <label className="text-sm font-semibold ml-1">Email Address</label>
                  <input 
                    required
                    type="email" 
                    placeholder="name@example.com"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-semibold ml-1">Password</label>
                  <input 
                    required
                    type="password" 
                    placeholder="••••••••"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                    value={formData.password}
                    onChange={e => setFormData({...formData, password: e.target.value})}
                  />
                </div>
                {authMode === 'register' && (
                  <div className="space-y-1">
                    <label className="text-sm font-semibold ml-1">Confirm Password</label>
                    <input 
                      required
                      type="password" 
                      placeholder="••••••••"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={formData.confirmPassword}
                      onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
                    />
                  </div>
                )}
                <button 
                  disabled={loading}
                  className="w-full py-4 bg-sky-600 text-white rounded-xl font-bold hover:bg-sky-700 transition-all shadow-lg shadow-sky-200 disabled:opacity-50"
                >
                  {loading ? 'Processing...' : (authMode === 'login' ? 'Sign In' : 'Create Account')}
                </button>
              </form>

              <div className="mt-8 pt-6 border-t border-slate-100 text-center">
                <button 
                  onClick={toggleAuthMode}
                  className="text-sky-600 font-semibold hover:underline"
                >
                  {authMode === 'login' ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
                </button>
              </div>
            </motion.div>
          </section>
        )}

        {currentPage === 'dashboard' && (
          user ? (
            <section className="pt-32 pb-20 px-6">
              <div className="max-w-7xl mx-auto">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
                  <div>
                    <h2 className="text-3xl font-display font-bold">Welcome, {user.name}</h2>
                    <p className="text-slate-500 capitalize">{user.role} Dashboard</p>
                  </div>
                  <div className="flex gap-3">
                    <div className="glass px-4 py-2 rounded-xl flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-sky-600" />
                      <span className="text-sm font-medium">{new Date().toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Patient Dashboard */}
                {user.role === 'patient' && (
                  <div className="grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                      {/* Book New */}
                      <div className="glass p-8 rounded-3xl">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                          <Plus className="w-5 h-5 text-sky-600" />
                          Book New Appointment
                        </h3>
                        <div className="grid md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <label className="text-sm font-semibold block">Select Doctor</label>
                            <select 
                              className="w-full p-3 rounded-xl border border-slate-200 outline-none"
                              id="book-doctor"
                            >
                              {doctors.map(d => <option key={d.id} value={d.id}>Dr. {d.name} ({d.specialization})</option>)}
                            </select>
                          </div>
                          <div className="space-y-4">
                            <label className="text-sm font-semibold block">Select Date</label>
                            <input type="date" className="w-full p-3 rounded-xl border border-slate-200 outline-none" id="book-date" min={new Date().toISOString().split('T')[0]} />
                          </div>
                          <div className="space-y-4">
                            <label className="text-sm font-semibold block">Select Time</label>
                            <select className="w-full p-3 rounded-xl border border-slate-200 outline-none" id="book-time">
                              {['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM'].map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                          </div>
                          <div className="flex items-end">
                            <button 
                              onClick={() => {
                                const dId = (document.getElementById('book-doctor') as HTMLSelectElement).value;
                                const date = (document.getElementById('book-date') as HTMLInputElement).value;
                                const time = (document.getElementById('book-time') as HTMLSelectElement).value;
                                if (date) handleBook(parseInt(dId), date, time);
                                else setMessage({ type: 'error', text: 'Please select a date' });
                              }}
                              className="w-full py-3 bg-sky-600 text-white rounded-xl font-bold hover:bg-sky-700 transition-all"
                            >
                              Confirm Booking
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* My Appointments */}
                      <div className="glass p-8 rounded-3xl">
                        <h3 className="text-xl font-bold mb-6">My Appointments</h3>
                        <div className="space-y-4">
                          {appointments.length === 0 ? (
                            <div className="text-center py-10 text-slate-400">No appointments found.</div>
                          ) : (
                            appointments.map(app => (
                              <div key={app.id} className="flex items-center justify-between p-4 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-all">
                                <div className="flex items-center gap-4">
                                  <div className="bg-sky-100 p-3 rounded-xl">
                                    <Calendar className="text-sky-600 w-5 h-5" />
                                  </div>
                                  <div>
                                    <h4 className="font-bold">Dr. {app.doctor_name}</h4>
                                    <p className="text-xs text-slate-500">{app.date} at {app.time}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-4">
                                  <div className="text-right mr-4">
                                    <span className={`block text-xs font-bold uppercase ${app.payment_status === 'completed' ? 'text-emerald-600' : 'text-amber-600'}`}>
                                      {app.payment_status === 'completed' ? 'Paid' : 'Unpaid'}
                                    </span>
                                    <span className="text-xs text-slate-400">₹{app.consultation_fee || 500}</span>
                                  </div>
                                  <span className={`px-3 py-1 rounded-full text-xs font-bold capitalize ${
                                    app.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 
                                    app.status === 'pending' ? 'bg-amber-100 text-amber-700' : 
                                    'bg-slate-100 text-slate-700'
                                  }`}>
                                    {app.status}
                                  </span>
                                  {app.status === 'pending' && (
                                    <button 
                                      onClick={() => updateAppointmentStatus(app.id, 'cancelled')}
                                      className="text-red-500 hover:text-red-700 text-sm font-semibold"
                                    >
                                      Cancel
                                    </button>
                                  )}
                                  {app.payment_status !== 'completed' && app.status !== 'cancelled' && (
                                    <button 
                                      onClick={() => {
                                        setSelectedAppointment(app);
                                        setShowPaymentModal(true);
                                      }}
                                      className="bg-sky-600 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-sky-700"
                                    >
                                      Pay Now
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-8">
                      {/* Profile Card */}
                      <div className="glass p-8 rounded-3xl text-center">
                        <div className="w-24 h-24 bg-sky-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                          <User className="w-12 h-12 text-sky-600" />
                        </div>
                        <h3 className="text-xl font-bold">{user.name}</h3>
                        <p className="text-slate-500 text-sm mb-6">{user.email}</p>
                        <div className="flex justify-center mb-6">
                          <div className="bg-slate-50 p-4 rounded-2xl min-w-[120px]">
                            <span className="block text-slate-400 text-xs mb-1 uppercase font-bold">Age</span>
                            <span className="font-bold text-lg">{user.age || '--'} Years</span>
                          </div>
                        </div>

                        <div className="pt-6 border-t border-slate-100">
                          {googleConnected ? (
                            <div className="flex items-center justify-center gap-2 text-emerald-600 font-bold text-sm">
                              <CheckCircle className="w-4 h-4" />
                              Google Connected
                            </div>
                          ) : (
                            <button 
                              onClick={handleGoogleConnect}
                              className="w-full py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-slate-50 transition-all"
                            >
                              <Mail className="w-4 h-4 text-red-500" />
                              Connect Gmail Reminders
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Quick Support */}
                      <div className="bg-slate-900 text-white p-8 rounded-3xl relative overflow-hidden">
                        <div className="relative z-10">
                          <h4 className="text-xl font-bold mb-2">Need Help?</h4>
                          <p className="text-slate-400 text-sm mb-6">Our support team is available 24/7 for your assistance.</p>
                          <button className="w-full py-3 bg-sky-600 rounded-xl font-bold hover:bg-sky-700 transition-all">
                            Contact Support
                          </button>
                        </div>
                        <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-sky-600/20 rounded-full blur-2xl"></div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Doctor Dashboard */}
                {user.role === 'doctor' && (
                  <div className="grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                      <div className="glass p-8 rounded-3xl">
                        <h3 className="text-xl font-bold mb-6">Patient Appointments</h3>
                        <div className="space-y-4">
                          {appointments.length === 0 ? (
                            <div className="text-center py-10 text-slate-400">No appointments scheduled.</div>
                          ) : (
                            appointments.map(app => (
                              <div key={app.id} className="p-6 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-all">
                                <div className="flex justify-between items-start mb-4">
                                  <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center">
                                      <User className="text-slate-400" />
                                    </div>
                                    <div>
                                      <h4 className="font-bold">{app.patient_name}</h4>
                                      <p className="text-xs text-slate-500">{app.date} at {app.time}</p>
                                    </div>
                                  </div>
                                  <span className={`px-3 py-1 rounded-full text-xs font-bold capitalize ${
                                    app.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 
                                    app.status === 'pending' ? 'bg-amber-100 text-amber-700' : 
                                    'bg-slate-100 text-slate-700'
                                  }`}>
                                    {app.status}
                                  </span>
                                </div>
                                {app.status === 'pending' && (
                                  <div className="flex gap-3">
                                    <button 
                                      onClick={() => updateAppointmentStatus(app.id, 'approved')}
                                      className="flex-1 py-2 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700 transition-all"
                                    >
                                      Approve
                                    </button>
                                    <button 
                                      onClick={() => updateAppointmentStatus(app.id, 'rejected')}
                                      className="flex-1 py-2 border border-red-200 text-red-600 rounded-lg font-bold hover:bg-red-50 transition-all"
                                    >
                                      Reject
                                    </button>
                                  </div>
                                )}
                                {app.status === 'approved' && (
                                  <button 
                                    onClick={() => updateAppointmentStatus(app.id, 'completed')}
                                    className="w-full py-2 bg-slate-900 text-white rounded-lg font-bold hover:bg-slate-800 transition-all"
                                  >
                                    Mark as Completed
                                  </button>
                                )}
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="space-y-8">
                      <div className="glass p-8 rounded-3xl">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                          <Clock className="w-5 h-5 text-sky-600" />
                          Availability Settings
                        </h3>
                        <div className="space-y-4">
                          <p className="text-sm text-slate-500 mb-4">Set your working hours for patients to book.</p>
                          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map(day => (
                            <div key={day} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                              <span className="text-sm font-semibold">{day}</span>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-emerald-600 font-bold">9:00 - 17:00</span>
                                <button className="text-sky-600 hover:text-sky-700"><Filter className="w-3 h-3" /></button>
                              </div>
                            </div>
                          ))}
                          <button className="w-full py-3 border border-sky-200 text-sky-600 rounded-xl font-bold hover:bg-sky-50 transition-all mt-4">
                            Update Schedule
                          </button>
                        </div>
                      </div>

                      <div className="glass p-8 rounded-3xl">
                        <h3 className="text-xl font-bold mb-6">Daily Overview</h3>
                        <div className="space-y-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="bg-sky-100 p-2 rounded-lg"><Clock className="text-sky-600 w-5 h-5" /></div>
                              <span className="text-slate-600">Total Today</span>
                            </div>
                            <span className="font-bold">{appointments.filter(a => a.date === new Date().toISOString().split('T')[0]).length}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="bg-emerald-100 p-2 rounded-lg"><CheckCircle className="text-emerald-600 w-5 h-5" /></div>
                              <span className="text-slate-600">Completed</span>
                            </div>
                            <span className="font-bold">{appointments.filter(a => a.status === 'completed').length}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Admin Dashboard */}
                {user.role === 'admin' && stats && (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      {[
                        { label: 'Total Patients', value: stats.totalPatients, icon: Users, color: 'bg-blue-500' },
                        { label: 'Total Doctors', value: stats.totalDoctors, icon: Stethoscope, color: 'bg-emerald-500' },
                        { label: 'Appointments', value: stats.totalAppointments, icon: Calendar, color: 'bg-amber-500' },
                        { label: 'Total Revenue', value: `₹${stats.revenue}`, icon: TrendingUp, color: 'bg-purple-500' },
                      ].map((stat, i) => (
                        <motion.div 
                          key={i}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: i * 0.1 }}
                          className="glass p-6 rounded-3xl"
                        >
                          <div className={`${stat.color} w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-lg`}>
                            <stat.icon className="text-white w-6 h-6" />
                          </div>
                          <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
                          <h4 className="text-2xl font-bold mt-1">{stat.value}</h4>
                        </motion.div>
                      ))}
                    </div>

                    <div className="grid lg:grid-cols-3 gap-8">
                      <div className="lg:col-span-2 space-y-8">
                        <div className="glass p-8 rounded-3xl">
                          <h3 className="text-xl font-bold mb-6 flex justify-between items-center">
                            Manage Doctors
                            <button 
                              onClick={openAddDoctorModal}
                              className="text-sm bg-sky-600 text-white px-4 py-2 rounded-xl hover:bg-sky-700 transition-all"
                            >
                              Add New Doctor
                            </button>
                          </h3>
                          <div className="overflow-x-auto">
                            <table className="w-full text-left">
                              <thead>
                                <tr className="text-slate-400 text-xs uppercase font-bold border-b border-slate-100">
                                  <th className="pb-4">Doctor</th>
                                  <th className="pb-4">Spec. & Degree</th>
                                  <th className="pb-4">Exp.</th>
                                  <th className="pb-4">Fee</th>
                                  <th className="pb-4">Actions</th>
                                </tr>
                              </thead>
                              <tbody className="text-sm">
                                {doctors.map(doc => (
                                  <tr key={doc.id} className="border-b border-slate-50">
                                    <td className="py-4">
                                      <p className="font-bold">Dr. {doc.name}</p>
                                      <p className="text-[10px] text-slate-400">{doc.qualification}</p>
                                    </td>
                                    <td className="py-4">
                                      <p className="text-slate-700 font-medium">{doc.specialization}</p>
                                      <p className="text-[10px] text-slate-400">{doc.degree}</p>
                                    </td>
                                    <td className="py-4 text-slate-500">{doc.experience} Yrs</td>
                                    <td className="py-4 font-bold">₹{doc.consultation_fee}</td>
                                    <td className="py-4">
                                      <button 
                                        onClick={() => openEditDoctorModal(doc)}
                                        className="text-sky-600 hover:text-sky-700 mr-3"
                                      >
                                        Edit
                                      </button>
                                      <button 
                                        onClick={() => handleDeleteDoctor(doc.id)}
                                        className="text-red-500 hover:text-red-700"
                                      >
                                        Delete
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <div className="glass p-8 rounded-3xl">
                          <h3 className="text-xl font-bold mb-6">Recent Activity</h3>
                        <div className="space-y-4">
                          {appointments.slice(0, 5).map(app => (
                            <div key={app.id} className="flex items-center justify-between p-4 border-b border-slate-50">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center">
                                  <User className="text-slate-400 w-5 h-5" />
                                </div>
                                <div>
                                  <p className="font-bold text-sm">{app.patient_name} booked with Dr. {app.doctor_name}</p>
                                  <p className="text-xs text-slate-400">{app.date} at {app.time}</p>
                                </div>
                              </div>
                              <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                                app.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 
                                'bg-slate-100 text-slate-700'
                              }`}>
                                {app.status}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="glass p-8 rounded-3xl">
                      <h3 className="text-xl font-bold mb-6">System Status</h3>
                        <div className="space-y-6">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-600">Server Status</span>
                            <span className="flex items-center gap-2 text-emerald-600 font-bold">
                              <div className="w-2 h-2 bg-emerald-600 rounded-full animate-pulse"></div>
                              Online
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-600">Database</span>
                            <span className="text-slate-900 font-bold">SQLite 3.x</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-600">Last Backup</span>
                            <span className="text-slate-900 font-bold text-sm">2 hours ago</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </section>
          ) : (
            <div className="pt-40 pb-20 px-6 flex flex-col items-center justify-center text-center">
              <div className="bg-sky-100 p-6 rounded-full mb-6">
                <ShieldCheck className="w-12 h-12 text-sky-600" />
              </div>
              <h2 className="text-3xl font-display font-bold mb-4">Login Required</h2>
              <p className="text-slate-500 mb-8 max-w-md">Please sign in to your account to access your personalized dashboard and book appointments.</p>
              <button 
                onClick={() => setCurrentPage('login')}
                className="bg-sky-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-sky-700 transition-all shadow-lg"
              >
                Go to Login
              </button>
            </div>
          )
        )}
      </main>

      <Footer />

      {/* Payment Modal */}
      <AnimatePresence>
        {showPaymentModal && selectedAppointment && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPaymentModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
            >
              <button 
                onClick={() => setShowPaymentModal(false)}
                className="absolute top-6 right-6 text-slate-400 hover:text-slate-600"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="text-center mb-8">
                <div className="bg-sky-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <CreditCard className="text-sky-600 w-8 h-8" />
                </div>
                <h3 className="text-2xl font-display font-bold">Secure Payment</h3>
                <p className="text-slate-500">Complete your booking for Dr. {selectedAppointment.doctor_name}</p>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl mb-8">
                <div className="flex justify-between mb-2">
                  <span className="text-slate-500">Consultation Fee</span>
                  <span className="font-bold">₹{selectedAppointment.consultation_fee || 500}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-slate-500">Service Fee</span>
                  <span className="font-bold">₹10</span>
                </div>
                <div className="border-t border-slate-200 mt-4 pt-4 flex justify-between">
                  <span className="font-bold">Total Amount</span>
                  <span className="text-xl font-bold text-sky-600">₹{(selectedAppointment.consultation_fee || 500) + 10}</span>
                </div>
              </div>

              <form onSubmit={handlePayment} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase text-slate-400 ml-1">Card Number</label>
                  <div className="relative">
                    <input 
                      required
                      type="text" 
                      inputMode="numeric"
                      pattern="[0-9]{16}"
                      maxLength={16}
                      onInput={(e) => e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, '')}
                      placeholder="4242424242424242"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all pl-12"
                    />
                    <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Expiry</label>
                    <input 
                      required
                      type="text" 
                      inputMode="numeric"
                      pattern="[0-9]{4}"
                      maxLength={4}
                      onInput={(e) => e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, '')}
                      placeholder="MMYY"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">CVC</label>
                    <input 
                      required
                      type="text" 
                      inputMode="numeric"
                      pattern="[0-9]{3}"
                      maxLength={3}
                      onInput={(e) => e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, '')}
                      placeholder="123"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                    />
                  </div>
                </div>
                <button 
                  disabled={paymentLoading}
                  className="w-full py-4 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {paymentLoading ? 'Processing...' : (
                    <>
                      <ShieldCheck className="w-5 h-5" />
                      Pay Securely
                    </>
                  )}
                </button>
              </form>
              
              <p className="text-center text-[10px] text-slate-400 mt-6">
                Your payment is processed securely via our demo gateway. <br />
                No real money will be charged.
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Doctor Management Modal */}
      <AnimatePresence>
        {showDoctorModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDoctorModal(false)}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white rounded-3xl p-8 w-full max-w-2xl shadow-2xl my-auto"
            >
              <button 
                onClick={() => setShowDoctorModal(false)}
                className="absolute top-6 right-6 text-slate-400 hover:text-slate-600"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="mb-8">
                <h3 className="text-2xl font-display font-bold">
                  {editingDoctor ? `Edit Dr. ${editingDoctor.name}` : 'Add New Doctor'}
                </h3>
                <p className="text-slate-500">
                  {editingDoctor ? 'Update doctor profile and credentials' : 'Create a new doctor account and profile'}
                </p>
              </div>

              <form onSubmit={editingDoctor ? handleUpdateDoctor : handleAddDoctor} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Full Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.name}
                      onChange={e => setDoctorFormData({...doctorFormData, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Email Address</label>
                    <input 
                      required
                      type="email" 
                      disabled={!!editingDoctor}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all disabled:bg-slate-50"
                      value={doctorFormData.email}
                      onChange={e => setDoctorFormData({...doctorFormData, email: e.target.value})}
                    />
                  </div>
                  {!editingDoctor && (
                    <div className="space-y-1">
                      <label className="text-xs font-bold uppercase text-slate-400 ml-1">Password</label>
                      <input 
                        required
                        type="password" 
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                        value={doctorFormData.password}
                        onChange={e => setDoctorFormData({...doctorFormData, password: e.target.value})}
                      />
                    </div>
                  )}
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Phone Number</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.phone}
                      onChange={e => setDoctorFormData({...doctorFormData, phone: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Specialization</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.specialization}
                      onChange={e => setDoctorFormData({...doctorFormData, specialization: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Degree</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.degree}
                      onChange={e => setDoctorFormData({...doctorFormData, degree: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Qualification</label>
                    <input 
                      required
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.qualification}
                      onChange={e => setDoctorFormData({...doctorFormData, qualification: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Experience (Years)</label>
                    <input 
                      required
                      type="number" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.experience}
                      onChange={e => setDoctorFormData({...doctorFormData, experience: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase text-slate-400 ml-1">Consultation Fee (₹)</label>
                    <input 
                      required
                      type="number" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                      value={doctorFormData.consultation_fee}
                      onChange={e => setDoctorFormData({...doctorFormData, consultation_fee: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase text-slate-400 ml-1">Bio / Description</label>
                  <textarea 
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                    value={doctorFormData.bio}
                    onChange={e => setDoctorFormData({...doctorFormData, bio: e.target.value})}
                  />
                </div>
                <button 
                  disabled={loading}
                  className="w-full py-4 bg-sky-600 text-white rounded-xl font-bold hover:bg-sky-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg"
                >
                  {loading ? 'Saving...' : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      {editingDoctor ? 'Update Doctor' : 'Create Doctor Account'}
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
